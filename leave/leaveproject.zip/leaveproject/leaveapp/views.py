from django.shortcuts import render, redirect

def home(request):

    leaves = request.session.get('leaves', [])
    return render(request, 'home.html', {'leaves': leaves})

def apply_leave(request):

    if request.method == "POST":
        name = request.POST.get('name')
        start_date = request.POST.get('start_date')
        end_date = request.POST.get('end_date')
        reason = request.POST.get('reason')

        leave = {
            'name': name,
            'start_date': start_date,
            'end_date': end_date,
            'reason': reason,
            'status': 'Pending'
        }

        leaves = request.session.get('leaves', [])
        leaves.append(leave)
        request.session['leaves'] = leaves

        return redirect('home')

    return render(request, 'apply_leave.html')

def cancel_leave(request, index):
    
    leaves = request.session.get('leaves', [])
    if 0 <= index < len(leaves):
        leaves[index]['status'] = 'Cancelled'
        request.session['leaves'] = leaves

    return redirect('home')
