from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('apply/', views.apply_leave, name='apply_leave'),
    path('cancel/<int:index>/', views.cancel_leave, name='cancel_leave'),
]
